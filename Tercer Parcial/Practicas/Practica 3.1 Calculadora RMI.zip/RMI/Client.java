//package hello;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class Client {

    private Client() {}

    public static void main(String[] args) {

	String host = (args.length < 1) ? null : args[0];
	try {
	    String expresion = new String();
            String Tipo = new String();
            Scanner teclado = new Scanner(System.in);
            Tipo = teclado.nextLine();
            switch (Tipo) {
                case "Infijo":
                case "infijo":
                case "Infija":
                case "infija":
                    {
                        expresion = teclado.nextLine();
                        Registry registry = LocateRegistry.getRegistry(host);
                        Suma stub = (Suma) registry.lookup("Suma");
                        Expresion mensaje = stub.Infija(expresion);
                        System.out.println("Mensaje: "+ mensaje.m+" v: "+mensaje.v);
                        break;
                    }
                case "Postfija":
                case "postfija":
                case "Postfijo":
                case "postfijo":
                    {
                        expresion = teclado.nextLine();
                        Registry registry = LocateRegistry.getRegistry(host);
                        Suma stub = (Suma) registry.lookup("Suma");
                        Expresion mensaje = stub.Postfija(expresion);
                        System.out.println("Mensaje: "+ mensaje.m+" v: "+mensaje.v);
                        break;
                    }
                case "Prefija":
                case "prefija":
                case "Prefijo":
                case "prefijo":
                    {
                        expresion = teclado.nextLine();
                        Registry registry = LocateRegistry.getRegistry(host);
                        Suma stub = (Suma) registry.lookup("Suma");
                        Expresion mensaje = stub.Prefija(expresion);
                        System.out.println("Mensaje: "+ mensaje.m+" v: "+mensaje.v);
                        break;
                    }
                default:
                    break;
            }
        } catch (Exception e) {
	    System.err.println("Client exception: " + e.toString());
	    e.printStackTrace();
	}
    }
}
