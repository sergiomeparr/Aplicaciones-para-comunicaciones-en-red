
import java.io.Serializable;

public class Expresion implements Serializable{
    String m;
    double v;
    
    public Expresion(String m, double v){
        this.m=m;
        this.v=v;
    }
    public static String getExpresion(){
        return "Un mensaje corto";
    }
}
