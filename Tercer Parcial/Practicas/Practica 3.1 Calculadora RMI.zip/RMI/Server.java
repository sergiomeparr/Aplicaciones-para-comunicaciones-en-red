//package hello;
	
import static java.lang.Math.sqrt;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
	
public class Server implements Suma {
	
    public Server() {}

    @Override
    public double suma(double a, double b) throws RemoteException {
	return a + b;
    }
    @Override
    public double resta(double a, double b) throws RemoteException{
	return a - b;
    }
    @Override
    public double multiplicacion(double a, double b) throws RemoteException{
	return a * b;
    }
    @Override
    public double division(double a, double b) throws RemoteException{
	return a / b;
    }
    @Override
    public double potencia(double a, double b) throws RemoteException{
	return Math.pow(b, a);
    }
    
    @Override
    public Expresion Prefija(String cadena) throws RemoteException {
        Stack <Double> numeros = new Stack<>();
        String numeros_grandes = new String();
        double resultado = 0;
        double aux = 0;
        double aux2 = 0;
        double aux3 = 0;
        int contador = 1;
        for(int i = 0; i < cadena.length(); i++){
            switch (cadena.charAt(i)) {
                case '+':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = suma(aux, aux2);
                    numeros.push(aux3);
                    break;
                case '-':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = resta(aux2, aux);
                    numeros.push(aux3);
                    break;
                case '*':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = multiplicacion(aux, aux2);
                    numeros.push(aux3);
                    break;
                case '/':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = division(aux2, aux);
                    numeros.push(aux3);
                    break;
                case '^':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = potencia(aux, aux2);
                    numeros.push(aux3);
                    break;
                //Caso para el seno, secante y raiz 
                case 's':
                    //Caso para el seno
                    if(cadena.charAt(i + 1) == 'e' && cadena.charAt(i + 2) == 'n'){
                        aux = numeros.pop();
                        aux3 = Math.sin(aux);
                        numeros.push(aux3);
                        i = i + 2;
                    }
                    //Caso para la secante
                    else if(cadena.charAt(i + 1) == 'e' && cadena.charAt(i + 2) == 'c'){
                        aux = numeros.pop();
                        aux3 = 1 / Math.cos(aux);
                        numeros.push(aux3);
                        i = i + 2;
                    }
                    else if(cadena.charAt(i + 1) == 'q' && cadena.charAt(i + 2) == 'r' && cadena.charAt(i + 3) == 't'){
                        aux = numeros.pop();
                        aux3 = Math.sqrt(aux);
                        numeros.push(aux3);
                        i = i + 3;
                    }
                    break;
                //Caso para el coseno, cosecante y cotangente
                case 'c':
                    //Caso para el coseno
                    if(cadena.charAt(i + 1) == 'o' && cadena.charAt(i + 2) == 's'){
                        aux = numeros.pop();
                        aux3 = Math.cos(aux);
                        numeros.push(aux3);
                    }
                    //Caso para la secante
                    else if(cadena.charAt(i + 1) == 's' && cadena.charAt(i + 2) == 'c'){
                        aux = numeros.pop();
                        aux3 = 1 / Math.sin(aux);
                        numeros.push(aux3);
                    }
                    //Caso para la cotangente
                    else if(cadena.charAt(i + 1) == 'o' && cadena.charAt(i + 2) == 't'){
                        aux = numeros.pop();
                        aux3 = Math.cos(aux) / Math.sin(aux);
                        numeros.push(aux3);
                    }
                    i = i + 2;
                    break;
                //Caso para el tangente
                case 't':
                    if(cadena.charAt(i + 1) == 'a' && cadena.charAt(i + 2) == 'n'){
                        aux = numeros.pop();
                        aux3 = Math.tan(aux);
                        numeros.push(aux3);
                    }
                    i = i + 2;
                    break;
                //Caso para el logaritmo
                case 'l':
                    if(cadena.charAt(i + 1) == 'o' && cadena.charAt(i + 2) == 'g'){
                        aux = numeros.pop();
                        aux3 = Math.log10(aux);
                        numeros.push(aux3);
                    }
                    i = i + 2;
                    break;
                case '(':
                    int inicio = i;    
                    int aux4 = 0;
                    if(inicio == 0){
                        aux4 = 1;
                    }
                    for(int j = i; j < cadena.length(); j++){
                        if(cadena.charAt(j) >= 48 && cadena.charAt(j) <= 57)
                            contador++;
                        if(cadena.charAt(j) == ')')
                            break;
                        i++;
                    }
                    numeros_grandes = cadena.substring(inicio + 1, contador + inicio);
                    aux = Double.parseDouble(numeros_grandes);
                    numeros.push(aux);
                    break;     
                default:
                    numeros.push((double)cadena.charAt(i) - '0');
                    break;
            }
            System.out.println(aux3);  
        }
        resultado = numeros.peek();
        numeros.pop();
        Expresion men = new Expresion(cadena, resultado);
        return men;
    }
    
    @Override
    public Expresion Postfija(String cadena) throws RemoteException {
        Stack <Double> numeros = new Stack<>();
        String numeros_grandes = new String();
        double resultado = 0;
        double aux = 0;
        double aux2 = 0;
        double aux3 = 0;
        int contador = 1;
        for(int i = 0; i < cadena.length(); i++){
            switch (cadena.charAt(i)) {
                case '+':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = suma(aux, aux2);
                    numeros.push(aux3);
                    break;
                case '-':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = resta(aux2, aux);
                    numeros.push(aux3);
                    break;
                case '*':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = multiplicacion(aux, aux2);
                    numeros.push(aux3);
                    break;
                case '/':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = division(aux2, aux);
                    numeros.push(aux3);
                    break;
                case '^':
                    aux = numeros.pop();
                    aux2 = numeros.pop();
                    aux3 = potencia(aux, aux2);
                    numeros.push(aux3);
                    break;
                //Caso para el seno, secante y raiz 
                case 's':
                    //Caso para el seno
                    if(cadena.charAt(i + 1) == 'e' && cadena.charAt(i + 2) == 'n'){
                        aux = numeros.pop();
                        aux3 = Math.sin(aux);
                        numeros.push(aux3);
                        i = i + 2;
                    }
                    //Caso para la secante
                    else if(cadena.charAt(i + 1) == 'e' && cadena.charAt(i + 2) == 'c'){
                        aux = numeros.pop();
                        aux3 = 1 / Math.cos(aux);
                        numeros.push(aux3);
                        i = i + 2;
                    }
                    else if(cadena.charAt(i + 1) == 'q' && cadena.charAt(i + 2) == 'r' && cadena.charAt(i + 3) == 't'){
                        aux = numeros.pop();
                        aux3 = Math.sqrt(aux);
                        numeros.push(aux3);
                        i = i + 3;
                    }
                    break;
                //Caso para el coseno, cosecante y cotangente
                case 'c':
                    //Caso para el coseno
                    if(cadena.charAt(i + 1) == 'o' && cadena.charAt(i + 2) == 's'){
                        aux = numeros.pop();
                        aux3 = Math.cos(aux);
                        numeros.push(aux3);
                    }
                    //Caso para la secante
                    else if(cadena.charAt(i + 1) == 's' && cadena.charAt(i + 2) == 'c'){
                        aux = numeros.pop();
                        aux3 = 1 / Math.sin(aux);
                        numeros.push(aux3);
                    }
                    //Caso para la cotangente
                    else if(cadena.charAt(i + 1) == 'o' && cadena.charAt(i + 2) == 't'){
                        aux = numeros.pop();
                        aux3 = Math.cos(aux) / Math.sin(aux);
                        numeros.push(aux3);
                    }
                    i = i + 2;
                    break;
                //Caso para el tangente
                case 't':
                    if(cadena.charAt(i + 1) == 'a' && cadena.charAt(i + 2) == 'n'){
                        aux = numeros.pop();
                        aux3 = Math.tan(aux);
                        numeros.push(aux3);
                    }
                    i = i + 2;
                    break;
                //Caso para el logaritmo
                case 'l':
                    if(cadena.charAt(i + 1) == 'o' && cadena.charAt(i + 2) == 'g'){
                        aux = numeros.pop();
                        aux3 = Math.log10(aux);
                        numeros.push(aux3);
                    }
                    i = i + 2;
                    break;
                case '(':
                    int inicio = i;    
                    int aux4 = 0;
                    if(inicio == 0){
                        aux4 = 1;
                    }
                    for(int j = i; j < cadena.length(); j++){
                        if(cadena.charAt(j) >= 48 && cadena.charAt(j) <= 57)
                            contador++;
                        if(cadena.charAt(j) == ')')
                            break;
                        i++;
                    }
                    numeros_grandes = cadena.substring(inicio + 1, contador + inicio);
                    aux = Double.parseDouble(numeros_grandes);
                    numeros.push(aux);
                    break;        
                default:
                    if(cadena.charAt(i) >= 48 && cadena.charAt(i) <= 57)
                        numeros.push((double)cadena.charAt(i) - '0');
                    break;
            }
            System.out.println(numeros);  
        }
        resultado = numeros.peek();
        numeros.pop();
        Expresion men = new Expresion(cadena, resultado);
        return men;
    }

    //Queda pendiente, faltan muchos casos que resolver
    @Override
    public Expresion Infija(String cadena) throws RemoteException{
        LinkedList numeros = new LinkedList();
        LinkedList resultados = new LinkedList();
        Stack operandos = new Stack();
        Stack <Double>evaluador = new Stack();
        String cadena_auxiliar;
        String ayuda = new String();
        double resultado = 0;
        double aux = 0;
        double aux2 = 0;
        double aux3 = 0;
        String numeros_grandes = new String();
        System.out.println(cadena);
        for(int i = 0; i < cadena.length(); i++){
            //----------------------------------------------------------------------------------------------------------------------
            //Cuando la pila esta vacia se ingresa cualquier operando//
            if(operandos.isEmpty()){
                //Resolver el caso de numeros grandes cuando la pila este vacia
                if((char)cadena.charAt(i) == '[' && (char)cadena.charAt(i + 2) >=48 && (char)cadena.charAt(i + 2) <=57){
                    numeros.add((char)cadena.charAt(i));
                    for(int j = i; j < cadena.length(); j++){
                        if((char)cadena.charAt(j) >=48 && (char)cadena.charAt(j) <=57)
                            numeros.add((char)cadena.charAt(j));
                        else if((char)cadena.charAt(j) == ']'){
                            numeros.add((char)cadena.charAt(j));
                            break;
                        }
                        i++;
                    }
                }
                else if((char)cadena.charAt(i) == '(' && (char)cadena.charAt(i + 2) >=48 && (char)cadena.charAt(i + 2) <=57){
                    numeros.add((char)cadena.charAt(i));
                    for(int j = i; j < cadena.length(); j++){
                        if((char)cadena.charAt(j) >=48 && (char)cadena.charAt(j) <=57)
                            numeros.add((char)cadena.charAt(j));
                        else if((char)cadena.charAt(j) == ')'){
                            numeros.add((char)cadena.charAt(j));
                            break;
                        }
                        i++;
                    }
                }
                else if((char)cadena.charAt(i) == '[' && (char)cadena.charAt(i + 2) <=48 && (char)cadena.charAt(i + 2) >=57)
                    operandos.push((char)cadena.charAt(i));
                
                else if((char)cadena.charAt(i) == '(' && (char)cadena.charAt(i + 2) <=48 && (char)cadena.charAt(i + 2) >=57)
                    operandos.push((char)cadena.charAt(i));
                   
                if(((char)cadena.charAt(i) == '+') || ((char)cadena.charAt(i) == '-') || ((char)cadena.charAt(i) == '*') 
                    || ((char)cadena.charAt(i) == '/') || ((char)cadena.charAt(i) == '^')){
                    operandos.push((char)cadena.charAt(i));
                }
                //Verificar si es seno//
                else if((char)cadena.charAt(i) == 's' && (char)cadena.charAt(i + 1) == 'e' && (char)cadena.charAt(i + 2) == 'n'){
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2; 
                }
                //Verificar si es coseno//
                else if((char)cadena.charAt(i) == 'c' && (char)cadena.charAt(i + 1) == 'o' && (char)cadena.charAt(i + 2) == 's'){
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2; 
                }
                //Verificar si es tangente//
                else if((char)cadena.charAt(i) == 't' && (char)cadena.charAt(i + 1) == 'a' && (char)cadena.charAt(i + 2) == 'n'){
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es cotangente//
                else if((char)cadena.charAt(i) == 'c' && (char)cadena.charAt(i + 1) == 'o' && (char)cadena.charAt(i + 2) == 't'){
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es cosecante//
                else if((char)cadena.charAt(i) == 'c' && (char)cadena.charAt(i + 1) == 's' && (char)cadena.charAt(i + 2) == 'c'){
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es secante//
                else if((char)cadena.charAt(i) == 's' && (char)cadena.charAt(i + 1) == 'e' && (char)cadena.charAt(i + 2) == 'c'){
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es logaritmo//
                else if((char)cadena.charAt(i) == 'l' && (char)cadena.charAt(i + 1) == 'o' && (char)cadena.charAt(i + 2) == 'g'){
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es raiz//
                else if((char)cadena.charAt(i) == 's' && (char)cadena.charAt(i + 1) == 'q' && (char)cadena.charAt(i + 2) == 'r'
                        && (char)cadena.charAt(i + 3) == 't'){
                    operandos.push((char)cadena.charAt(i + 3));
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 3;
                }
                //Si son numeros
                else if((char)cadena.charAt(i) >= 48 && (char)cadena.charAt(i) <= 57)
                    numeros.add((char)cadena.charAt(i));
            }
            //---------------------------------------------------------------------------------------------------------------------
        
            //Cuando la pila no es vacia, se revisa las prioridades de los operandos
            else if(!operandos.isEmpty()){
                //Si son numeros grandes, mayores a 2 digitos
                if((char)cadena.charAt(i) == '(' && ((char)cadena.charAt(i + 2) >= 48  && (char)cadena.charAt(i + 2) <= 57)){
                   numeros.add((char)cadena.charAt(i));
                    for(int j = i; j < cadena.length(); j++){
                        if((char)cadena.charAt(j) >=48 && (char)cadena.charAt(j) <=57)
                            numeros.add((char)cadena.charAt(j));
                        else if((char)cadena.charAt(j) == ')'){
                            numeros.add((char)cadena.charAt(j));
                            break;
                        }
                        i++;
                    }
                }
                //Si son numeros grandes, mayores a 2 digitos
                else if((char)cadena.charAt(i) == '[' && ((char)cadena.charAt(i + 2) >= 48  && (char)cadena.charAt(i + 2) <= 57)){
                    numeros.add((char)cadena.charAt(i));
                    for(int j = i; j < cadena.length(); j++){
                        if((char)cadena.charAt(j) >=48 && (char)cadena.charAt(j) <=57)
                            numeros.add((char)cadena.charAt(j));
                        else if((char)cadena.charAt(j) == ')'){
                            numeros.add((char)cadena.charAt(j));
                            break;
                        }
                        i++;
                    }
                }
                
                else if((char)cadena.charAt(i) == '(' && ((char)cadena.charAt(i + 2) <= 48  && (char)cadena.charAt(i + 2) <= 57))
                    operandos.push((char)cadena.charAt(i));
                else if((char)cadena.charAt(i) == '[' && ((char)cadena.charAt(i + 2) <= 48  && (char)cadena.charAt(i + 2) <= 57))
                    operandos.push((char)cadena.charAt(i));
                
                //Verificar la prioridad de la suma//
                else if((((char)cadena.charAt(i) == '+') && ((char)operandos.peek() == '-')) 
                    || (((char)cadena.charAt(i) == '+') && ((char)operandos.peek() == '*'))
                    || (((char)cadena.charAt(i) == '+') && ((char)operandos.peek() == '/')) 
                    || (((char)cadena.charAt(i) == '+') && ((char)operandos.peek() == '^'))
                    || (((char)cadena.charAt(i) == '+') && ((char)operandos.peek() == '+'))){        
                    numeros.add((char)operandos.pop());
                    operandos.push((char)cadena.charAt(i));
                }
                else if((((char)cadena.charAt(i) == '+') && ((char)operandos.peek() == '(')))
                    operandos.push((char)cadena.charAt(i));
        
                //Verificar la prioridad de la resta//
                else if((((char)cadena.charAt(i) == '-') && ((char)operandos.peek() == '+')) 
                    || (((char)cadena.charAt(i) == '-') && ((char)operandos.peek() == '*'))
                    || (((char)cadena.charAt(i) == '-') && ((char)operandos.peek() == '/')) 
                    || (((char)cadena.charAt(i) == '-') && ((char)operandos.peek() == '^'))
                    || (((char)cadena.charAt(i) == '-') && ((char)operandos.peek() == '-'))){        
                    numeros.add((char)operandos.pop());
                    operandos.push((char)cadena.charAt(i));
                }
                else if((((char)cadena.charAt(i) == '-') && ((char)operandos.peek() == '(')))
                    operandos.push((char)cadena.charAt(i));
        
                //Verificar la prioridad de la multiplicacion//
                else if((((char)cadena.charAt(i) == '*') && ((char)operandos.peek() == '+')) 
                        || (((char)cadena.charAt(i) == '*') && ((char)operandos.peek() == '('))
                        || (((char)cadena.charAt(i) == '*') && ((char)operandos.peek() == '-'))){        
                    operandos.push((char)cadena.charAt(i));
                }
                else if((((char)cadena.charAt(i) == '*') && ((char)operandos.peek() == '*')) 
                        || (((char)cadena.charAt(i) == '*') && ((char)operandos.peek() == '/'))
                        || (((char)cadena.charAt(i) == '*') && ((char)operandos.peek() == '^'))){        
                    numeros.add((char)operandos.pop());
                    operandos.push((char)cadena.charAt(i));
                }
                
                //Verificar la prioridad de la division//
                else if((((char)cadena.charAt(i) == '/') && ((char)operandos.peek() == '+')) 
                        || (((char)cadena.charAt(i) == '/') && ((char)operandos.peek() == '('))
                        || (((char)cadena.charAt(i) == '/') && ((char)operandos.peek() == '-'))
                        || (((char)cadena.charAt(i) == '/') && ((char)operandos.peek() == '*'))){        
                    operandos.push((char)cadena.charAt(i));
                }
                else if((((char)cadena.charAt(i) == '/') && ((char)operandos.peek() == '/'))
                        || (((char)cadena.charAt(i) == '/') && ((char)operandos.peek() == '^'))){        
                    numeros.add((char)operandos.pop());
                    operandos.push((char)cadena.charAt(i));
                }
                
                //Verificar la prioridad de la potencia//
                else if((((char)cadena.charAt(i) == '^') && ((char)operandos.peek() == '+')) 
                        || (((char)cadena.charAt(i) == '^') && ((char)operandos.peek() == '('))
                        || (((char)cadena.charAt(i) == '^') && ((char)operandos.peek() == '-'))
                        || (((char)cadena.charAt(i) == '^') && ((char)operandos.peek() == '*'))
                        || (((char)cadena.charAt(i) == '^') && ((char)operandos.peek() == '/'))){        
                    operandos.push((char)cadena.charAt(i));
                }
                else if((((char)cadena.charAt(i) == '^') && ((char)operandos.peek() == '^'))){        
                    numeros.add((char)operandos.pop());
                    operandos.push((char)cadena.charAt(i));
                }
                
                //Verificar si es seno //
                else if((char)cadena.charAt(i) == 's' && (char)cadena.charAt(i + 1) == 'e' && (char)cadena.charAt(i + 2) == 'n'){ 
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es coseno //
                else if((char)cadena.charAt(i) == 'c' && (char)cadena.charAt(i + 1) == 'o' && (char)cadena.charAt(i + 2) == 's'){ 
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es tangente //
                else if((char)cadena.charAt(i) == 't' && (char)cadena.charAt(i + 1) == 'a' && (char)cadena.charAt(i + 2) == 'n'){ 
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es cotangente //
                else if((char)cadena.charAt(i) == 'c' && (char)cadena.charAt(i + 1) == 'o' && (char)cadena.charAt(i + 2) == 't'){ 
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es secante //
                else if((char)cadena.charAt(i) == 's' && (char)cadena.charAt(i + 1) == 'e' && (char)cadena.charAt(i + 2) == 'c'){ 
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es cosecante //
                else if((char)cadena.charAt(i) == 'c' && (char)cadena.charAt(i + 1) == 's' && (char)cadena.charAt(i + 2) == 'c'){ 
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es logaritmo //
                else if((char)cadena.charAt(i) == 'l' && (char)cadena.charAt(i + 1) == 'o' && (char)cadena.charAt(i + 2) == 'g'){ 
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 2;
                }
                //Verificar si es raiz //
                else if((char)cadena.charAt(i) == 's' && (char)cadena.charAt(i + 1) == 'q' && (char)cadena.charAt(i + 2) == 'r'
                        && (char)cadena.charAt(i + 3) == 't'){ 
                    operandos.push((char)cadena.charAt(i + 3));
                    operandos.push((char)cadena.charAt(i + 2));
                    operandos.push((char)cadena.charAt(i + 1));
                    operandos.push((char)cadena.charAt(i));
                    i = i + 3;
                }
                //Si es un corchete que cierra, sacamos elementos de la pila y los ingresamos a la lista//
                else if(((char)cadena.charAt(i) == ']')){
                    while(!operandos.isEmpty()){
                        if((char)operandos.peek() == '[' || (char)operandos.peek() == ']')
                            operandos.pop();
                        else if((char)operandos.peek() != '[' || (char)operandos.peek() != ']')
                            numeros.add((char)operandos.pop());
                    }
                }       
                //Si es un parentesis que cierra, sacamos elementos de la pila y los ingresamos a la lista//   
                else if((char)cadena.charAt(i) == ')'){
                    while(!operandos.isEmpty()){
                        if((char)operandos.peek() == '(' || (char)operandos.peek() == ')')
                            operandos.pop();
                        else if((char)operandos.peek() != '(' || (char)operandos.peek() != ')')
                            numeros.add((char)operandos.pop());
                        
                    }
                }
                //Si son numeros//
                else if((char)cadena.charAt(i) >= 48 && (char)cadena.charAt(i) <= 57)
                    numeros.add((char)cadena.charAt(i));
            }
        }
        while(!operandos.isEmpty())
            numeros.add((char)operandos.pop());
        cadena_auxiliar = numeros.toString();
        int contador = 0;
        char[] cadena_auxiliar2 = new char[cadena_auxiliar.length()];
        for(int i = 0; i < cadena_auxiliar.length(); i++){
            if(cadena_auxiliar.charAt(i) != '[' && cadena_auxiliar.charAt(i) != ',' && cadena_auxiliar.charAt(i) != ' ' 
                    && cadena_auxiliar.charAt(i) != ']'){
                cadena_auxiliar2[contador] = cadena_auxiliar.charAt(i);
                contador++;
            }
        }
        System.out.println(cadena_auxiliar2);
        System.out.println(numeros);
        //Ahora resolvemos las expresiones
        for(int i = 0; i < cadena_auxiliar2.length; i++){
            switch (cadena_auxiliar2[i]) {
                case '+':
                    aux = evaluador.pop();
                    aux2 = evaluador.pop();
                    aux3 = suma(aux, aux2);
                    evaluador.push(aux3);
                    break;
                case '-':
                    aux = evaluador.pop();
                    aux2 = evaluador.pop();
                    aux3 = resta(aux2, aux);
                    evaluador.push(aux3);
                    break;
                case '*':
                    aux = evaluador.pop();
                    aux2 = evaluador.pop();
                    aux3 = multiplicacion(aux, aux2);
                    evaluador.push(aux3);
                    break;
                case '/':
                    aux = evaluador.pop();
                    aux2 = evaluador.pop();
                    aux3 = division(aux2, aux);
                    evaluador.push(aux3);
                    break;
                case '^':
                    aux = evaluador.pop();
                    aux2 = evaluador.pop();
                    aux3 = potencia(aux, aux2);
                    evaluador.push(aux3);
                    break;
                //Caso para el seno, secante y raiz 
                case 's':
                    //Caso para el seno
                    if(cadena_auxiliar2[i + 1] == 'e' && cadena_auxiliar2[i + 2] == 'n'){
                        aux = evaluador.pop();
                        aux3 = Math.sin(aux);
                        evaluador.push(aux3);
                        i = i + 2;
                    }
                    //Caso para la secante
                    else if(cadena_auxiliar2[i + 1] == 'e' && cadena_auxiliar2[i + 2] == 'c'){
                        aux = evaluador.pop();
                        aux3 = 1 / Math.sin(aux);
                        evaluador.push(aux3);
                        i = i + 2;
                    }
                    else if(cadena_auxiliar2[i + 1] == 'q' && cadena_auxiliar2[i + 2] == 'r' 
                            && cadena_auxiliar2[i + 3] == 't'){
                        aux = evaluador.pop();
                        aux3 = sqrt(aux);
                        evaluador.push(aux3);
                        i = i + 3;
                    }
                    break;
                //Caso para el coseno, cosecante y cotangente
                case 'c':
                    //Caso para el coseno
                    if(cadena_auxiliar2[i + 1] == 'o' && cadena_auxiliar2[i + 2] == 's'){
                        aux = evaluador.pop();
                        aux3 = Math.cos(aux);
                        evaluador.push(aux3);
                    }
                    //Caso para la secante
                    else if(cadena_auxiliar2[i + 1] == 's' && cadena_auxiliar2[i + 2] == 'c'){
                        aux = evaluador.pop();
                        aux3 = 1 / Math.cos(aux);
                        evaluador.push(aux3);
                    }
                    //Caso para la cotangente
                    else if(cadena_auxiliar2[i + 1] == 'o' && cadena_auxiliar2[i + 2] == 't'){
                        aux = evaluador.pop();
                        aux3 = Math.cos(aux) / Math.sin(aux);
                        evaluador.push(aux3);
                    }
                    i = i + 2;
                    break;
                //Caso para el tangente
                case 't':
                    if(cadena_auxiliar2[i + 1] == 'a' && cadena_auxiliar2[i + 2] == 'n'){
                        aux = evaluador.pop();
                        aux3 = Math.tan(aux);
                        evaluador.push(aux3);
                    }
                    i = i + 2;
                    break;
                //Caso para el logaritmo
                case 'l':
                    if(cadena_auxiliar2[i + 1] == 'o' && cadena_auxiliar2[i + 2] == 'g'){
                        aux = evaluador.pop();
                        aux3 = Math.log10(aux);
                        evaluador.push(aux3);
                    }
                    i = i + 2;
                    break;
                case '(':
                    for(int j = i; j < cadena_auxiliar2.length; j++){
                        if(cadena_auxiliar2[j] >= 48 && cadena_auxiliar2[j] <= 57){
                            numeros_grandes = numeros_grandes + Character.toString(cadena_auxiliar2[j]);
                            contador++;
                        }
                        if(cadena_auxiliar2[j] == ')')
                            break;
                        i++;
                    }
                    aux = Double.parseDouble(numeros_grandes);
                    System.out.println(aux);
                    evaluador.push(aux);
                    break;        
                default:
                    if(cadena_auxiliar2[i] >= 48 && cadena_auxiliar2[i] <= 57)
                        evaluador.push((double)cadena_auxiliar2[i] - '0');
                    break;
            }
        }
        resultado = evaluador.peek();
        evaluador.pop();
        Expresion men = new Expresion(cadena, resultado);
        return men;
    }
    
    public static void main(String args[]) {
	try {
            java.rmi.registry.LocateRegistry.createRegistry(1099); //puerto default del rmiregistry
            System.out.println("RMI registry ready.");
        } catch (Exception e) {
            System.out.println("Exception starting RMI registry:");
            e.printStackTrace();
        }//catch
	try {
            System.setProperty("java.rmi.server.codebase","http://8.25.100.18/clases/"); ///file:///f:\\redes2\\RMI\\RMI2
	    Server obj = new Server();
	    Suma stub = (Suma) UnicastRemoteObject.exportObject(obj, 0);
	    // Bind the remote object's stub in the registry
	    Registry registry = LocateRegistry.getRegistry();
	    registry.bind("Suma", stub);
	    System.err.println("Servidor listo...");
	} catch (Exception e) {
	    System.err.println("Server exception: " + e.toString());
	    e.printStackTrace();
	}
    }

}
