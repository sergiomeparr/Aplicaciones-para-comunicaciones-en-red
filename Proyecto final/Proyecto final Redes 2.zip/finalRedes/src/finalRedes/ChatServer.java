
package practica4chat;

import java.net.*;
import java.io.*;
import java.net.UnknownHostException;


public class ChatServer implements Runnable {
        String dir= "230.1.1.1";
        InetAddress grupo= null;
        String []nombres=new String[10];
        String []dirIP=new String[10];
        String user="Conectados:\n";
        int contdatos=0;

    public void run(){
        try{
                grupo= InetAddress.getByName(dir);
        }catch(UnknownHostException uhe){
                System.err.println("Dirección no valida");
                System.exit(0);
        }
        
        
        for(;;){
            
            try{
                MulticastSocket s= new MulticastSocket(4000);
                //s.setTimeToLive(255);
                s.joinGroup(grupo);
                System.out.println("Unido al grupo "+dir);
                
                byte[] buf = new byte[1<<11];//crea arreglo de bytes 
                DatagramPacket recv = new DatagramPacket(buf,buf.length);//crea el datagram packet a recibir
                s.receive(recv);
                
                byte [] data = recv.getData(); //aqui no se entienden los datos
    		//System.out.println("Datos recibidos: " + new String(data));
                System.out.print("MENSAJE DEL CLIENTE"+ data.toString()+"\n");
                String dat= new String(recv.getData());
                System.out.print("MENSAJE DEL CLIENTE "+ dat+"\n");
                
                if(new String(data).indexOf("info") != -1){//guardo los usuario y su ip
                    String []limpia=new String(data).split(" ");
                    String []separa=limpia[1].split("/");
                    nombres[contdatos]=separa[0];
                    dirIP[contdatos]=separa[1];
                    
                    int list=0;
                    
                    System.out.println("Conectado "+nombres[contdatos]);
                    
                    String strconectado="inicio-"+nombres[contdatos];
                    
                    System.out.println(strconectado);
                    DatagramPacket inpack=new DatagramPacket(strconectado.getBytes(),strconectado.length(),grupo,4000);
                    s.send(inpack);
                    
                    
                    user=user+nombres[contdatos]+"\n";
                    System.out.println(user);
                    
                    contdatos++;
                }if(new String(data).indexOf("need-") != -1){
                    
                    String needs="Lista-"+user;
                     DatagramPacket lista=new DatagramPacket(needs.getBytes(),needs.length(),grupo,4000);
                     s.send(lista);
                     System.out.println(needs);
                }else{ /*if(new String(data).indexOf("msj") != -1){
                    DatagramPacket mensajepacket = new DatagramPacket(new String(data).getBytes(),new String(data).length(),grupo,4000);
                    s.send(mensajepacket);*/
                    System.out.println(dat);
                }
                
            }catch(Exception e){
                e.printStackTrace();
            }//catch
        }//for
    
    }
    
    public static void main(String[] args) {
        try{
            (new Thread(new ChatServer())).start();
        }catch(Exception e){
            e.printStackTrace();
        }
         
    }//main
    
}//class
