/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4chat;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.videoio.VideoCapture;


/**
 *
 * @author Ayrton
 */
public class Snapshot extends javax.swing.JFrame {
    
    
    // definitions
    String dir= "230.1.1.1";
        InetAddress grupo= null;
        String []nombres=new String[10];
        String []dirIP=new String[10];
        String user="Conectados:\n";
        int contdatos=0;
 private DaemonThread myThread = null;
    int count = 0;
    VideoCapture webSource = null;
    int num=0;

    Mat frame = new Mat();
    MatOfByte mem = new MatOfByte();
    
    
    
    
////////////////////////////////////////////////////////////
    
    class DaemonThread implements Runnable
    {
    protected volatile boolean runnable = false;

    @Override
    public  void run()
    {
        try{
                grupo= InetAddress.getByName(dir);
        }catch(UnknownHostException uhe){
                System.err.println("Dirección no valida");
                System.exit(0);
        }
        
        synchronized(this)
        {
            while(runnable)
            {
                if(webSource.grab())
                {
		    	try
                        {
                            webSource.retrieve(frame);
			    Imgcodecs.imencode(".bmp", frame, mem);
			    Image im = ImageIO.read(new ByteArrayInputStream(mem.toArray()));

			    BufferedImage buff = (BufferedImage) im;
			    Graphics g=jPanel1.getGraphics();
                            
                            Imgcodecs.imwrite("C:\\Users\\Ayrton\\Documents\\Streaming\\temp"+num+".jpg", frame);
                            num++;
                            //String path="C:\\Users\\Ayrton\\Documents\\Streaming\\temp"+num+".jpg";

			    if (g.drawImage(buff, 0, 0, getWidth(), getHeight() -150 , 0, 0, buff.getWidth(), buff.getHeight(), null))
			    
                                /*try{
                                    MulticastSocket c1= new MulticastSocket(4000);
                                    //s.setTimeToLive(255);
                                    c1.joinGroup(grupo);
                                    System.out.println("Unido al grupo "+dir);
                                     
                                    String mm="stream-";
                                    DatagramPacket infoarch=new DatagramPacket(mm.getBytes(),mm.length(),grupo,4000);
                                    c1.send(infoarch);
                                    
                                    File f=new File(path);
                                    
                                    String nom=f.getName();
                                    long tam=f.length();
                                    System.out.println("NOMBRE Y TAM DE SNAPSHOT ES: "+nom+": "+tam);
                                    System.out.println("Path es: "+path);
                                    
                                    ByteArrayOutputStream baos=new ByteArrayOutputStream();
                                    DataOutputStream dos= new DataOutputStream(baos);
                                    DataInputStream dis= new DataInputStream(new FileInputStream(path));        
                    
                    
                    
                                    String dname=nom;
                                    System.out.println(dname);
                                    dos.writeUTF(dname);
                                    dos.flush();
                    
                    
                                    dos.writeLong(tam);
                                    dos.flush();
                                    
                                    int n1=0;
                                    long enviados=0;
                                    
                                    byte[] buf5= new byte[2000];
                                    byte[] b= baos.toByteArray();
                                    DatagramPacket datam0=new DatagramPacket(b,b.length,grupo,4000);
                                    c1.send(datam0);
                                    
                                    while(enviados<tam){
                                            n1=dis.read(buf5);
                        
                                            enviados= enviados+n1;
                        
                                           
                                            DatagramPacket datam2=new DatagramPacket(buf5,n1,grupo,4000);
                                            c1.send(datam2);
                                            System.out.println("TAMAÑO ENVIADOS: "+datam2.getLength());
                        
                                            int porcentaje= (int)((enviados*100)/tam);
                                            System.out.println("ENVIADOS: "+enviados);
                                            System.out.println("Se ha enviado el "+porcentaje+"%");
                        
                                      
                                    }
                                    dis.close();
                                    dos.close();
                                    
                                    
                                    
                                    }catch(Exception e){
                                    e.printStackTrace();
                                    }*/
			    if(runnable == false)
                            {
			    	System.out.println("Going to wait()");
			    	this.wait();
			    }
			 }
			 catch(Exception ex)
                         {
			    System.out.println("Error");
                         }
                }
            }
        }
     }
   }
   /////////////////////////////////////////////////////////

    /**
     * Creates new form Snapshot
     */
    public Snapshot() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFileChooser1 = new javax.swing.JFileChooser();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 643, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 419, Short.MAX_VALUE)
        );

        jButton1.setText("Grabar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Pausar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Mandar video");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(jButton1)
                        .addGap(45, 45, 45)
                        .addComponent(jButton2)
                        .addGap(54, 54, 54)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        webSource =new VideoCapture(0);
        myThread = new DaemonThread();
            Thread t = new Thread(myThread);
            t.setDaemon(true);
            myThread.runnable = true;
            t.start();
			 jButton1.setEnabled(false);  //start button
            jButton2.setEnabled(true);  // stop button
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        myThread.runnable = false;
            jButton2.setEnabled(false);   
            jButton1.setEnabled(true);
            //this.dispose();
            webSource.release();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        /*int returnVal = jFileChooser1.showSaveDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
        File file = jFileChooser1.getSelectedFile();
        Imgcodecs.imwrite(file.getPath(), frame);
        
        System.out.println("Ruta: "+file.getPath());
        } else {
            System.out.println("File access cancelled by user.");
        }*/
        
        try{
                                    MulticastSocket c1= new MulticastSocket(4000);
                                    //s.setTimeToLive(255);
                                    c1.joinGroup(grupo);
                                    System.out.println("Unido al grupo "+dir);
                                    int cont=85;
                                    
                                    while(cont<num){
                                    String mm="stream-";
                                    String path="C:\\Users\\Ayrton\\Documents\\Streaming\\temp"+cont+".jpg";
                                    DatagramPacket infoarch=new DatagramPacket(mm.getBytes(),mm.length(),grupo,4000);
                                    c1.send(infoarch);
                                    
                                    File f=new File(path);
                                    
                                    String nom=f.getName();
                                    long tam=f.length();
                                    System.out.println("NOMBRE Y TAM DE SNAPSHOT ES: "+nom+": "+tam);
                                    System.out.println("Path es: "+path);
                                    
                                    ByteArrayOutputStream baos=new ByteArrayOutputStream();
                                    DataOutputStream dos= new DataOutputStream(baos);
                                    DataInputStream dis= new DataInputStream(new FileInputStream(path));        
                    
                    
                    
                                    String dname=nom;
                                    System.out.println(dname);
                                    dos.writeUTF(dname);
                                    dos.flush();
                    
                    
                                    dos.writeLong(tam);
                                    dos.flush();
                                    
                                    int n1=0;
                                    long enviados=0;
                                    
                                    byte[] buf5= new byte[2000];
                                    byte[] b= baos.toByteArray();
                                    DatagramPacket datam0=new DatagramPacket(b,b.length,grupo,4000);
                                    c1.send(datam0);
                                    
                                    while(enviados<tam){
                                            n1=dis.read(buf5);
                        
                                            enviados= enviados+n1;
                        
                                           
                                            DatagramPacket datam2=new DatagramPacket(buf5,n1,grupo,4000);
                                            c1.send(datam2);
                                            System.out.println("TAMAÑO ENVIADOS: "+datam2.getLength());
                        
                                            int porcentaje= (int)((enviados*100)/tam);
                                            System.out.println("ENVIADOS: "+enviados);
                                            System.out.println("Se ha enviado el "+porcentaje+"%");
                        
                                      
                                    }
                                    dis.close();
                                    dos.close();
                                    cont++;
                                    }
                                    num=0;
                                    cont=0;
                                    this.dispose();
                                    
                                    }catch(Exception e){
                                    e.printStackTrace();
                                    }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME); // load native library of o
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Snapshot.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Snapshot.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Snapshot.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Snapshot.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Snapshot().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
