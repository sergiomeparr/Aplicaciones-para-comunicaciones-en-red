
package Pract1;

import java.io.*;
import java.net.*;

public class Servidor_Practica {
    public static void main(String[] args){
        try{
            String nombre = null;
            String auxiliar = null;
            String auxiliar2 = null;
            DataOutputStream dos = null;                                                                //añadido
            DataInputStream dis = null;                                                                 //añadido
            ServerSocket s = new ServerSocket(7000);
            BufferedReader br2 = null;
            BufferedReader br3 = null;
            BufferedReader br4 = null;
            boolean habilitar;
            for(;;){
                int cantidad = 1;
                int i = 0;
                int contador = 0;
                int buffer = 0;
                Socket cl = s.accept();
                br3 = new BufferedReader(new InputStreamReader(cl.getInputStream()));
                br2 = new BufferedReader(new InputStreamReader(cl.getInputStream()));
                br4 = new BufferedReader(new InputStreamReader(cl.getInputStream()));
                auxiliar = br3.readLine();                                                                //añadido  
                habilitar = Boolean.parseBoolean(auxiliar);
                cl.setTcpNoDelay(habilitar);
                System.out.println("\n\nConexion establecida desde: "+ cl.getInetAddress()+ ":"+ cl.getPort());                                                                               //añadido
                auxiliar = br2.readLine();                                                                //añadido  
                cantidad = Integer.parseInt(auxiliar);              
                auxiliar2 = br4.readLine();                                                                //añadido  
                buffer = Integer.parseInt(auxiliar2); 
                byte[] b = new byte[buffer];
                while(i < cantidad){                                                                      //añadido
                    dis = new DataInputStream(cl.getInputStream());
                    nombre =  dis.readUTF();
                    System.out.println("\n--------------------------------------------");                 //añadido                             
                    System.out.println("Recibimos el archivo: "+ nombre);                                 
                    long tam = dis.readLong();
                    dos = new DataOutputStream(new FileOutputStream(nombre));
                    long recibidos = 0;
                    int n, porcentaje = 0;
                    while(recibidos < tam){
                        n = dis.read(b);
                        dos.write(b, 0, n);
                        dos.flush();
                        recibidos = recibidos + n;
                        porcentaje = (int)(recibidos * 100 / tam);
                        /*if(contador % 8 == 0)
                            System.out.print("\n");
                        else
                            System.out.print(porcentaje + "% cargado, ");*/
                        contador += 1;
                    }
                    System.out.print("\t -->>Archivo Recibido: "+ porcentaje + "% cargado");
                    i += 1;
                }   
                dos.close();
                dis.close();
                cl.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
 

