
package Pract1;

import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class Servidor extends javax.swing.JFrame {
    Socket cl;
    private static javax.swing.JTextArea jTextArea2;
    private static javax.swing.JScrollPane jScrollPane2;
    public Servidor() {
        initComponents();
        setLocation(80,100);
        this.setTitle("Servidor");
        //this.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 617, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        new Servidor().setVisible(true);
        try{
            String nombre = null;
            String auxiliar = null;
            String auxiliar2 = null;
            String auxiliar3 = null;
            DataOutputStream dos = null;                                                                
            DataInputStream dis = null;                                                                 
            ServerSocket s = new ServerSocket(7000);
            BufferedReader br2 = null;
            BufferedReader br3 = null;
            BufferedReader br4 = null;
            BufferedReader br5 = null;
            boolean habilitar;
            for(;;){
                int cantidad = 1;
                int i = 0;
                int contador = 0;
                int buffer = 0;
                Socket cl = s.accept();
                br3 = new BufferedReader(new InputStreamReader(cl.getInputStream()));
                br2 = new BufferedReader(new InputStreamReader(cl.getInputStream()));
                br4 = new BufferedReader(new InputStreamReader(cl.getInputStream()));
                auxiliar = br3.readLine();                                                                 
                habilitar = Boolean.parseBoolean(auxiliar);
                cl.setTcpNoDelay(habilitar);
                jTextArea2.append("\n-------------------------------------------------------------------------------------------");
                jTextArea2.append("\n\nConexion establecida desde: "+ cl.getInetAddress() + ":" + cl.getPort());
                auxiliar = br2.readLine();                                                                 
                cantidad = Integer.parseInt(auxiliar);              
                auxiliar2 = br4.readLine();                                                                  
                buffer = Integer.parseInt(auxiliar2); 
                byte[] b = new byte[buffer];
                while(i < cantidad){                                                                      
                    dis = new DataInputStream(cl.getInputStream());
                    nombre =  dis.readUTF();
                    jTextArea2.append("\nRecibimos el archivo: " + nombre);                                 
                    long tam = dis.readLong();
                    dos = new DataOutputStream(new FileOutputStream(nombre));
                    long recibidos = 0;
                    int n, porcentaje = 0;
                    while(recibidos < tam){
                        n =  dis.read(b, 0, Math.min(1024, (int) (tam - recibidos)));
                        dos.write(b, 0, n);
                        dos.flush();
                        recibidos = recibidos + n;
                        porcentaje = (int)(recibidos * 100 / tam);
                        //contador += 1;
                    }
                    jTextArea2.append("\n\t -->>Archivo Recibido: "+ porcentaje + "% cargado");
                    i += 1;
                }   
                dos.close();
                dis.close();
                cl.close();
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }/*
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
*/}
