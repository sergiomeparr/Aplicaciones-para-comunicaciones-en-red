package Pract1;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class Cliente_Practica {
    public static void main(String[] args){
        try{
            int cantidad = 0;
            boolean habilitar;
            DataOutputStream dos = null;                                                   //añadido
            DataInputStream dis = null;                                                    //añadido
            String nombre = null;
            String archivo = null; 
            PrintWriter pw = null;
            PrintWriter pwhabilitar = null;
            PrintWriter pwbytes = null;
            long tam = 0;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.printf("Escriba la direccion: ");
            String host = br.readLine();
            System.out.printf("\nEscriba el puerto: ");
            int pto = Integer.parseInt(br.readLine());
            Socket cl = new Socket(host, pto);
            System.out.printf("\n¿Quieres habilitar el algoritmo de naggle ? S/N: ");
            String respuesta = br.readLine();
            System.out.printf("\n Tamano del buffer: ");
            int buffer = Integer.parseInt(br.readLine());
            if(respuesta == "Si" || respuesta == "si"){
                habilitar = true;
                cl.setTcpNoDelay(habilitar);
            }
            else{
                habilitar = false;
                cl.setTcpNoDelay(habilitar);
            }
            pwhabilitar = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
            pwhabilitar.println(habilitar);
            pwhabilitar.flush();
            
            JFileChooser jf  = new JFileChooser();           
            jf.setFileSelectionMode(JFileChooser.APPROVE_OPTION);
            if (!jf.isMultiSelectionEnabled()) {
                jf.setMultiSelectionEnabled(true);
            }            
            int returnVal = jf.showOpenDialog(null);
            File[] files = jf.getSelectedFiles();
            cantidad = files.length;
            pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
            pw.println(cantidad);
            pw.flush();
            
            pwbytes = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
            pwbytes.println(buffer);
            pwbytes.flush();
            
            for (int i = 0; i < files.length; i++){
                int contador = 0;
                archivo = files[i].getPath();
                nombre = files[i].getName();
                tam = files[i].length();
                dos = new DataOutputStream(cl.getOutputStream());
                dis = new DataInputStream(new FileInputStream(files[i].getPath()));
                dos.writeUTF(nombre);
                dos.flush();
                dos.writeLong(tam);
                dos.flush();
                byte[] b = new byte[buffer];
                long enviados = 0;
                int porcentaje = 0, n;
                while(enviados < tam){
                    n = dis.read(b);
                    dos.write(b, 0, n);
                    //dos.write(b, 0, (int) Math.min(0, tam - enviados));
                    dos.flush();
                    enviados = enviados + n;
                    porcentaje = (int)(enviados * 100 / tam);
                    /*if(contador % 8 == 0)
                        System.out.print("\n");
                    else
                        System.out.print(porcentaje +" % enviando, ");*/
                    contador += 1;
                }
                System.out.print("\n----->Archivo "+ (i + 1) + ", " + porcentaje+ "% enviado: "+ files[i].getName() +"\n");
            }
            dos.close();
            dis.close();
            pw.close();
            pwhabilitar.close();
            pwbytes.close();
            cl.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
