/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2A;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import sharedClasses.Producto;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Cliente extends javax.swing.JFrame {

    private ArrayList<Producto> catalogo;
    private DefaultTableModel modelo;
    private ArrayList<Producto> compra;
    private int unisamsung;
    private int unisony;
    private int unipanasonic;
    private int unitashi;
    private int unisharp;
    private int unilg;
    
    /**
     * Creates new form Cliente
     */
    public Cliente() {
        unisamsung=0;
         unisony=0;
    unipanasonic=0;
    unitashi=0;
     unisharp=0;
     unilg=0;
        initComponents();
        this.actualizarButton.setVisible(false);
        this.compra = new ArrayList();
        this.catalogo = new ArrayList();
        this.pideCatalogo();
        modelo = new MyModel();


        modelo.addColumn("Nombre");
        modelo.addColumn("Descripcion");
        modelo.addColumn("Precio");
        modelo.addColumn("Existencias");
        modelo.addColumn("Compras");



        jTable1.setModel(modelo);
        for (int i = 0; i < catalogo.size(); i++) {
            modelo.addRow(catalogo.get(i).getDatos());

        }

    }
    /**
     *
     * @variables
     * <Variables predeterminadas en el sistema>
     * final int PORT <Puerto al que se ha de comunicar el cliente >
     * final int SERVER <Servidor al que se comunica el cliente>
     * final int SEND <Codigo de envio hacia el servidor>
     *
     */
    public final String SERVER = new String("127.0.0.1");
    public final int PORT = 9090, SEND = 1;

    /**
     * Metodo Compra
     *
     */
    String total="" ;
    double suma=0;
    public void comprarCosas() {
        try {
             
            Socket cliente = new Socket(InetAddress.getByName(SERVER), PORT);
            cliente.setSoLinger(true, 1);
            ObjectOutputStream oos = new ObjectOutputStream(cliente.getOutputStream());
            //JOptionPane.showMessageDialog(null,""+cliente.getOutputStream().t);
            oos.writeObject("2");
            ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());

            oos.writeInt(this.catalogo.size());
            
            int aux, dis;
            for (int i = 0; i < this.modelo.getRowCount(); i++) {
                catalogo.get(i).setCompra(Integer.parseInt((String)this.modelo.getValueAt(i, 4)));
                //JOptionPane.showMessageDialog(null,""+this.modelo.getValueAt(i, 4));
                    aux = Integer.parseInt((String)this.modelo.getValueAt(i, 4));
                    dis = Integer.parseInt((String)this.modelo.getValueAt(i, 3));
                if(i==0)
                    if(aux < dis){
                    unisamsung+=Integer.parseInt((String)this.modelo.getValueAt(i, 4));
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "el producto Samsung no tiene "+aux+" disponibles");
                        this.modelo.setValueAt(0, i, 4);
                    }
                if(i==1)
                    if(aux < dis){
                    unisony+=Integer.parseInt((String)this.modelo.getValueAt(i, 4));
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "el producto Sony no tiene "+aux+" disponibles");
                        this.modelo.setValueAt(0, i, 4);
                    }
                if(i==2)
                    if(aux < dis){
                    unipanasonic+=Integer.parseInt((String)this.modelo.getValueAt(i, 4));
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "el producto Panasonic no tiene "+aux+" disponibles");
                        unipanasonic+=0;
                        this.modelo.setValueAt(0, i, 4);
                    }
                if(i==3)
                    if(aux < dis){
                    unitashi+=Integer.parseInt((String)this.modelo.getValueAt(i, 4));
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "el producto Tashi no tiene "+aux+" disponibles");
                        unitashi+=0;
                        this.modelo.setValueAt(0, i, 4);
                    }
                if(i==4)
                    if(aux < dis){
                    unisharp+=Integer.parseInt((String)this.modelo.getValueAt(i, 4));
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "el producto Sharp no tiene "+aux+" disponibles");
                        unitashi+=0;
                        this.modelo.setValueAt(0, i, 4);
                    }
                if(i==5)
                    if(aux < dis){
                    unilg+=Integer.parseInt((String)this.modelo.getValueAt(i, 4));
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "el producto LG no tiene "+aux+" disponibles");
                        unilg+=0;
                        this.modelo.setValueAt(0, i, 4);
                    }
                oos.writeObject(catalogo.get(i));
            }
            
            total= (String)ois.readObject();
            suma+= Double.parseDouble(total);
            
            if(suma>=0)
            {
                totalCompra.setText(""+suma);
                JOptionPane.showMessageDialog(null, "Compra exitosa");
            }
            
            this.actualizaCatalogo();
            this.actualizaCatalogo();
            
        } catch (UnknownHostException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Metodo ActualizaCatalogo <Invoca a pidecatalogo y actualiza las filas de
     * la tabla>
     *
     * @return ArrayList
     *
     */
    public ArrayList<Producto> actualizaCatalogo() {
        System.out.println(this.modelo.getRowCount());
        if (this.modelo.getRowCount() > 0) {
            for (int i = this.modelo.getRowCount() - 1; i > -1; i--) {
                this.modelo.removeRow(i);
            }


        }
        for (int i = 0; i < catalogo.size(); i++) {
            modelo.addRow(catalogo.get(i).getDatos());
        }
        return this.pideCatalogo();
    }

    /**
     * Metodo PideCatalogo <Entrega el catalogo de productos>
     *
     * @param <ArrayList>
     * @return
     */
    public ArrayList<Producto> pideCatalogo() {
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        try {

            /*
             * Creamos el socket y pedimos el catalogo
             */
            Socket cliente = new Socket(InetAddress.getByName(SERVER), PORT);
            System.out.println("Conectado;");
            cliente.setSoLinger(true, 1);
            oos = new ObjectOutputStream(cliente.getOutputStream());
            //Código de petición de catalogo
            oos.writeObject("1");
            ois = new ObjectInputStream(cliente.getInputStream());
            int numero = Integer.parseInt((String) ois.readObject());
            System.out.println("Recibi: " + numero);

            /*
             * Borramos el arrayList y la tabla
             */
            this.catalogo.clear();

            for (int i = 0; i < numero; i++) {
                Producto prod = (Producto) ois.readObject();
                this.catalogo.add(prod);
                System.out.println("Recibi producto: " + catalogo.get(i).getNombre());
            }
            cliente.close();
            return this.catalogo;





        } catch (UnknownHostException ex) {
            Logger.getLogger(Cliente.class
                    .getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class
                    .getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

        return null;

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        comprar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        totalCompra = new javax.swing.JLabel();
        finalizarbtn = new javax.swing.JButton();
        actualizarButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                jTable1InputMethodTextChanged(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        comprar.setText("Comprar");
        comprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comprarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jLabel1.setText("Total de compra:");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jLabel2.setText("$");

        totalCompra.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        totalCompra.setText("0.0");

        finalizarbtn.setText("Finalizar compra");
        finalizarbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finalizarbtnActionPerformed(evt);
            }
        });

        actualizarButton.setText("actualizar");

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
            .add(layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(comprar)
                        .add(145, 145, 145)
                        .add(jLabel1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel2)
                        .add(22, 22, 22)
                        .add(totalCompra))
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 514, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(layout.createSequentialGroup()
                        .add(finalizarbtn)
                        .add(148, 148, 148)
                        .add(actualizarButton)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 130, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(comprar)
                    .add(jLabel1)
                    .add(totalCompra)
                    .add(jLabel2))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(finalizarbtn)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(actualizarButton)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comprarActionPerformed
        this.comprarCosas();
    }//GEN-LAST:event_comprarActionPerformed

    private void finalizarbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finalizarbtnActionPerformed
        // TODO add your handling code here:
        int res=JOptionPane.showConfirmDialog(null, "¿DESEA TERMINAR SU COMPRA?");
        Cliente cl = new Cliente();
        if(res==0){
            JOptionPane.showMessageDialog(null, "GRACIAS POR SU COMPRA, HASTA PRONTO!!!");
            totalCompraTicket();
            System.exit(0);
        }
        else
            JOptionPane.showMessageDialog(null, "CONTINUE CON SU COMPRA");
    }//GEN-LAST:event_finalizarbtnActionPerformed

    private void jTable1InputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jTable1InputMethodTextChanged
        System.out.println("Cambie algo");
    }//GEN-LAST:event_jTable1InputMethodTextChanged

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if(evt.getClickCount()==2){
        switch(jTable1.getSelectedRow()){
            case 0:
                Fondo f1 = new Fondo();
                f1.setSize(400, 300);
                f1.setVisible(true);
                Panel p1 = new Panel("/Imagenes/samsung.jpg");
                f1.add(p1);
                System.out.print("Samdufh");
                break;
            case 1:
                Fondo f2 = new Fondo();
                f2.setSize(400, 300);
                f2.setVisible(true);
                Panel p2 = new Panel("/Imagenes/sony.jpg");
                f2.add(p2);
                break;
            case 2:
                Fondo f3 = new Fondo();
                f3.setSize(400, 300);
                f3.setVisible(true);
                Panel p3 = new Panel("/Imagenes/panasonic.jpg");
                f3.add(p3);
                break;
            case 3:
                Fondo f4 = new Fondo();
                f4.setSize(400, 300);
                f4.setVisible(true);
                Panel p4 = new Panel("/Imagenes/sharp.jpg");
                f4.add(p4);
                break;
            case 4:
                Fondo f5 = new Fondo();
                f5.setSize(400, 300);
                f5.setVisible(true);
                Panel p5 = new Panel("/Imagenes/sony.jpg");
                f5.add(p5);
                break;
            case 5:
                Fondo f6 = new Fondo();
                f6.setSize(400, 300);
                f6.setVisible(true);
                Panel p6 = new Panel("/Imagenes/lg.jpg");
                f6.add(p6);
                break;
            
        }
        }
    }//GEN-LAST:event_jTable1MouseClicked

    
    
    public void totalCompraTicket(){
    JOptionPane.showMessageDialog(null,"******************"
                                +"\nEL TOTAL DE LA COMPRA FUE DE:"+this.totalCompra.getText()
                                +"\nLOS ARTICULOS COMPRADOD FUERON:\n"
                                + "\nMARCA         PRECIO     UNIDADES      SUBTOTAL\n"
                                 + "\nSAMSUNG        5500              "+this.unisamsung+"                      "+(5500*unisamsung)
                                 + "\nSONY               9500                "+this.unisony+"                      "+(9500*unisony)
                                 + "\nPANASONIC   10500              "+this.unipanasonic+"                     "+(10500*unipanasonic)
                                 + "\nTASHI               10700             "+this.unitashi+"                    "+(10700*unitashi)
                                 + "\nSHARP             13000              "+this.unisharp+"                      "+(13000*unisharp)
                                 + "\nLG                     12000              "+this.unilg+"                      "+(12000*unilg)
                                 + "\n*******************\n"
                                 + "EL TOTAL DE LA COMPRA ES: "+this.totalCompra.getText());
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;


                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente().setVisible(true);
            }
        });
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualizarButton;
    private javax.swing.JButton comprar;
    private javax.swing.JButton finalizarbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel totalCompra;
    // End of variables declaration//GEN-END:variables
}
