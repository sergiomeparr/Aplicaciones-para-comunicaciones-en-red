package Socket_de_Flujo_Bloqueantes;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class ClienteArchivo {
    public static void main(String[] args){
        try{
            DataOutputStream dos = null;                                                   //añadido
            DataInputStream dis = null;                                                    //añadido
            Scanner teclado = new Scanner(System.in);                                      //añadido
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.printf("Escriba la direccion: ");
            String host = br.readLine();
            System.out.printf("\nEscriba el puerto: ");
            int pto = Integer.parseInt(br.readLine());
            Socket cl = new Socket(host, pto);
            System.out.printf("\n¿Cuantos archivos quieres enviar? : ");                   //añadido
            int cantidad = teclado.nextInt();                                              //añadido
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));//añadido
            int i = 0;                                                                     //añadido
            pw.println(cantidad);                                                          //añadido
            pw.flush();                                                                    //añadido
            while(i < cantidad){
                JFileChooser jf  = new JFileChooser();              
                int r = jf.showOpenDialog(null);
                if(r == JFileChooser.APPROVE_OPTION){                
                    File f = jf.getSelectedFile();
                    String archivo = f.getAbsolutePath();
                    String nombre = f.getName();
                    long tam = f.length();
                    dos = new DataOutputStream(cl.getOutputStream());
                    dis = new DataInputStream(new FileInputStream(archivo));
                    dos.writeUTF(nombre);
                    dos.flush();
                    dos.writeLong(tam);
                    dos.flush();
                    byte[] b = new byte[1024];
                    long enviados = 0;
                    int porcentaje = 0, n;
                    while(enviados < tam){
                        n = dis.read(b);
                        dos.write(b, 0, n);
                        dos.flush();
                        enviados = enviados + n;
                        porcentaje = (int)(enviados * 100 / tam);
                    }
                    System.out.print("\n----->Archivo "+ (i + 1) +", "+porcentaje+ " % enviado: "+  nombre);
                    i += 1;                                                                //añadido
                }
            }
            dos.close();
            dis.close();
            pw.close();                                                                    //añadido  
            cl.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}