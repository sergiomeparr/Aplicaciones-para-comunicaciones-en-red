
package Socket_de_Flujo_Bloqueantes;

import java.io.*;
import java.net.*;

public class ServidorArchivo {
    public static void main(String[] args){
        try{
            DataOutputStream dos = null;                                                              //añadido
            DataInputStream dis = null;                                                               //añadido
            ServerSocket s = new ServerSocket(7000);
            for(;;){
                Socket cl = s.accept();
                System.out.println("\n\nConexion establecida desde: "+ cl.getInetAddress()+ ":"+ cl.getPort());
                BufferedReader br2 = new BufferedReader(new InputStreamReader(cl.getInputStream()));  //añadido
                String auxiliar = br2.readLine();                                                     //añadido  
                int cantidad = Integer.parseInt(auxiliar);                                            //añadido
                System.out.println("Numero de archivos: "+cantidad);                                  //añadido
                int i = 0;                                                                            //añadido
                while(i < cantidad){                                                                  //añadido
                    dis = new DataInputStream(cl.getInputStream());
                    byte[] b = new byte[1024];
                    String nombre =  dis.readUTF();
                    System.out.println("\n--------------------------------------------");               //añadido                             
                    System.out.println("Recibimos el archivo: "+ nombre);                                 
                    long tam = dis.readLong();
                    dos = new DataOutputStream(new FileOutputStream(nombre));
                    long recibidos = 0;
                    int n, porcentaje = 0;
                    while(recibidos < tam){
                        n = dis.read(b);
                        dos.write(b, 0, n);
                        dos.flush();
                        recibidos = recibidos + n;
                        porcentaje = (int)(recibidos * 100 / tam);
                    }
                    System.out.print("\t -->>Archivo Recibido: "+ porcentaje + "% cargado");
                    i += 1;                                                                          //añadido
                }
                dos.close();
                dis.close();
                cl.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
