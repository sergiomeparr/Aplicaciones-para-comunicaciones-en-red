package socket_de_datagrama_chat;

import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class Cliente_chat extends javax.swing.JFrame {

    public static javax.swing.JLabel jLabel1;
    public static javax.swing.JScrollPane jScrollPane2;
    public static javax.swing.JTextArea jTextArea2;
    public static javax.swing.JTextField jTextField1;    
    public static DatagramSocket cl;
    public static int i = 0;
    public static int cantidad;
    
    public Cliente_chat() {
        initComponents();
        setTitle("Cliente");
        setLocation(710,220);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Mensaje");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField1KeyPressed(evt);
            }
        });

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyPressed
        int code = evt.getKeyCode();
        //Variables para hacer subcadenas de un mensaje
        int Index = 0, Final = 20;
        String cantidad;
        int residuo = 0;
        int pto = 2000;
        int longi = 0;
        int division;
        String texto;
        if(code == KeyEvent.VK_ENTER){
            try{
                //Direccion de envio
                String dst = "127.0.0.1";
                
                //Obtencion de la cadena
                String mensaje = jTextField1.getText();
                jTextArea2.append("-------->Cliente: "+ mensaje +"\n");
                byte[] b = mensaje.getBytes();
                
                //Cierre del programa si el mensaje es Adios
                if("Adios".equals(mensaje)){
                    System.exit(0);
                }
                else{
                    //Longitud del mensaje
                    int longitud = b.length;
                        
                    //Si la cadena es menor a 20 caracteres
                    if(longitud <= 20){
                        cantidad = "0";
                        byte[] tam = cantidad.getBytes(); 
                        DatagramPacket p1 = new DatagramPacket(tam, tam.length, InetAddress.getByName(dst), pto);
                        cl.send(p1);
                        DatagramPacket p = new DatagramPacket(b, b.length, InetAddress.getByName(dst), pto);
                        cl.send(p);
                        residuo = 0;
                        String msj2 = Integer.toString(residuo);
                        byte[] n = msj2.getBytes();
                        DatagramPacket p2 = new DatagramPacket(n, n.length, InetAddress.getByName(dst), pto);
                        cl.send(p2);
                    }
                    //Si la cadena es mayor a los caracteres permitidos
                    else{
                        division = b.length / 20;
                        residuo = b.length - (division * 20);
                        String msj2 = Integer.toString(residuo);
                        
                        cantidad = Integer.toString(division);
                        byte[] tam = cantidad.getBytes(); 
                        DatagramPacket p1 = new DatagramPacket(tam, tam.length, InetAddress.getByName(dst), pto);
                        cl.send(p1);
                        
                        
                        //Envio consecutivo de mensaje al servidor
                        for(int i = 0; i < division; i++){
                            //subcadenas
                            texto = mensaje.substring(Index, Final);
                            byte[] c = texto.getBytes();
                            DatagramPacket p = new DatagramPacket(c, c.length, InetAddress.getByName(dst), pto);
                            cl.send(p);
                            Index = Final;
                            Final = Final + 20;
                        }
                        
                        //Se envia el tamaño del residuo
                        byte[] n = msj2.getBytes();
                        DatagramPacket p2 = new DatagramPacket(n, n.length, InetAddress.getByName(dst), pto);
                        cl.send(p2);
                        
                        //Si queda un residuo del mensaje, tambien se envia
                        if(residuo > 0){
                            texto = mensaje.substring( longitud - residuo, longitud);
                            byte[] a = texto.getBytes();
                            DatagramPacket p = new DatagramPacket(a, a.length, InetAddress.getByName(dst), pto);
                            cl.send(p);
                        }
                    }
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            jTextField1.setText(" ");
        }
    }//GEN-LAST:event_jTextField1KeyPressed

    public static void main(String args[]) {
        new Cliente_chat().setVisible(true);
        String msj = "";
        //Recibir mensaje del cliente
        try{
            cl = new DatagramSocket(2001);  
            //ciclo infinito
            while(true){
                String auxiliar = null;
                
                //Bandera para saber cuantas subcadenas hay
                DatagramPacket p1 = new DatagramPacket(new byte[3], 3); 
                cl.receive(p1);
                String msj1 = new String(p1.getData(), 0, p1.getLength());
                int cantidad = Integer.parseInt(msj1);
                
                //Esto sirve para que no haya errores en la lectura de las subcadena
                if(cantidad > 0)
                    cantidad = cantidad - 1;
                
                //ciclo para concatenar las subcadenas en una sola
                for(int i = 0; i < cantidad + 1; i++){
                    DatagramPacket p = new DatagramPacket(new byte[20], 20); 
                    cl.receive(p);
                    auxiliar = new String(p.getData(), 0, p.getLength());
                    msj = msj + auxiliar;
                    auxiliar = "";
                }
                
                DatagramPacket p3 = new DatagramPacket(new byte[3], 3); 
                cl.receive(p3);
                String msj4 = new String(p3.getData(), 0, p3.getLength());       
                int resul = Integer.parseInt(msj4);
                
                //residuo por si falta una subcadena
                if(resul > 0){
                    DatagramPacket p2 = new DatagramPacket(new byte[resul], resul); 
                    cl.receive(p2);
                    String msj3 = new String(p2.getData(), 0, p2.getLength());       
                    msj = msj + msj3;
                    msj3 = "";
                }
                jTextArea2.append("---->Mensaje Cliente: "+ msj +"\n");
                msj = "";
                //jTextArea2.append("residuo: "+ resul);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        
        
    }
/*
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
*/}
