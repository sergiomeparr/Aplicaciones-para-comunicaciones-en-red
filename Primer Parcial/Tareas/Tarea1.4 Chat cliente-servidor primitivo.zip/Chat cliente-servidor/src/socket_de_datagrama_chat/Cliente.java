
package socket_de_datagrama_chat;

import java.net.*;
import java.io.*;

//modificar para que por lo menos se tenga un chat basico entre cliente y servidor e incluir una restriccion, reducir 
//el buffer a 20 y un control por si hay mas de 20 caracteres 

public class Cliente {
    public static void main(String args[]){
        try{
            boolean resultado = true;
            DatagramSocket cl = new DatagramSocket(2001);  //definimos el socket de datagrama
            System.out.println("Cliente iniciado, escriba un mensaje de saludo: ");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));  //definimos buffer de lectura para mensaje
            String mensaje = br.readLine();
            if(mensaje == "Terminar" || mensaje == "terminar"){
                cl.close();
                System.exit(0);
            }
            else{
                byte[] b = mensaje.getBytes(); 
                String dst = "127.0.0.1";
                int pto = 2000;
                DatagramPacket p = new DatagramPacket(b, b.length, InetAddress.getByName(dst), pto);
                cl.send(p);
                resultado = recibir_mensaje(dst, pto, cl);
                if(resultado == false)
                    cl.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public static boolean recibir_mensaje(String dst, int pto, DatagramSocket cl){
        boolean resultado =  true;
        DatagramPacket p = null;
        try{
            if(resultado == false)
                cl.close();
            else{
                p = new DatagramPacket(new byte [2000], 2000);
                cl.receive(p);
                System.out.println("_________________________________________\n");
                System.out.println("Datagrama recibido desde: "+ p.getAddress() +" : "+ p.getPort()+"\n");
                String msj = new String(p.getData(), 0, p.getLength());
                System.out.println("---->Mensaje del Servidor: "+ msj);
                if(msj == "Terminar" || msj == "terminar"){
                    resultado = false;
                }
                else
                    resultado = enviar_mensaje(dst, pto, cl);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return resultado;
    }
    
    public static boolean enviar_mensaje(String dst, int pto, DatagramSocket cl){
        boolean resultado =  true;
        DatagramPacket p = null;  
        BufferedReader br;  //definimos buffer de lectura para mensaje
        BufferedReader br1;  
        String mensaje = null;
        PrintWriter pr = null;
        int cont = 1;
        try{
            if(resultado == false)
                cl.close();
            else{
                System.out.println("_________________________________________\n");
                System.out.println("Mensaje para el Servidor: ");
                br = new BufferedReader(new InputStreamReader(System.in));
                br1 = new BufferedReader(new InputStreamReader(System.in));
                mensaje = br.readLine();
                byte[] b = mensaje.getBytes(); 
                p = new DatagramPacket(b, b.length, InetAddress.getByName(dst), pto);
                cl.send(p);
                if(mensaje == "Terminar" || mensaje == "terminar"){
                    resultado = false;
                }
                else
                    resultado = recibir_mensaje(dst, pto, cl);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return resultado;
    }
}
