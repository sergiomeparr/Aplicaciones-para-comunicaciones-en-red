package socket_de_datagrama_chat;

import java.net.*;
import java.io.*;

public class Servidor {
    public static void main(String args[]){
        try{
            String dst = "127.0.0.1";
            int pto = 2001, i = 0, cantidad = 1;
            DatagramSocket s = new DatagramSocket(2000);  
            System.out.println("Servidor Iniciado, esperando cliente\n\n");
            for(;;){
                //while(i < cantidad){
                    DatagramPacket p = new DatagramPacket(new byte[2000], 2000); 
                    s.receive(p);     
                    System.out.println("_________________________________________\n");
                    System.out.println("Datagrama recibido desde: "+ p.getAddress() +" : "+ p.getPort()+"\n");
                    String msj = new String(p.getData(), 0, p.getLength());
                    System.out.println("---->Mensaje del Cliente: "+ msj);
                    System.out.println("_________________________________________\n");
                /*    System.out.println("Mensaje para el Cliente: ");
                    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));  
                    String mensaje = br.readLine();
                    byte[] b = mensaje.getBytes(); 
                    DatagramPacket p1 = new DatagramPacket(b, b.length, InetAddress.getByName(dst), pto);
                    s.send(p1);
               }*/
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }    
}
