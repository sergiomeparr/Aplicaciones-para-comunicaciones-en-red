
package Socket_de_Flujo_Bloqueantes;

//Cliente

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente {
    public static void main(String[] args){
       try{
            Scanner sc = new Scanner(System.in);                                            //añadido
            String mensaje_servidor = "HOLA SERVIDOR";                                      //añadido
            BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
            System.out.printf("Escriba la direccion: ");
            String host = br1.readLine();
            System.out.printf("\nEscriba el puerto: ");
            int pto = Integer.parseInt(br1.readLine());
            System.out.printf("\nIntroduzca un mensaje para el servidor: ");
            mensaje_servidor = sc.nextLine();
            Socket c1 = new Socket(host, pto);
            BufferedReader br2 = new BufferedReader(new InputStreamReader(c1.getInputStream()));
            String mensaje = br2.readLine();
            System.out.println("Recibimos un mensaje desde el servidor");
            System.out.printf("Mensaje: "+mensaje);
            System.out.println("\n\nEnviando mensaje al servidor");                         //añadido
            System.out.printf("\n-----------------------------------------------------\n");
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(c1.getOutputStream())); //añadido     
            pw.println(mensaje_servidor);                                                   //añadido
            pw.flush();                                                                     //añadido
            pw.close();                                                                     //añadido
            br1.close(); 
            br2.close();
            c1.close();
       }catch(Exception e){
           e.printStackTrace();
       }
   }
}
