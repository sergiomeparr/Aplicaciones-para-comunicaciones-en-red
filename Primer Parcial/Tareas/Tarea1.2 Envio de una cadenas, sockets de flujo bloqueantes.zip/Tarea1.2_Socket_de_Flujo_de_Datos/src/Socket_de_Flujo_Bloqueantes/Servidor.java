
package Socket_de_Flujo_Bloqueantes;

//Servidor

import java.io.*;
import java.net.*;


public class Servidor {
    public static void main(String[] args){
       try{
           ServerSocket s = new ServerSocket(1234);
           System.out.println("Esperando cliente....");
           for(;;){
               Socket cl = s.accept();
               System.out.println("Conexion establecida desde"+ cl.getInetAddress()+":"+cl.getPort());
               String mensaje = " Hola mundo";
               PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
               pw.println(mensaje);
               pw.flush();
               BufferedReader br2 = new BufferedReader(new InputStreamReader(cl.getInputStream()));  //añadido
               String mensaje_servidor = br2.readLine();                                             //añadido
               System.out.println("\n\nRecibimos un mensaje desde el cliente");                      //añadido
               System.out.printf("Mensaje: "+mensaje_servidor+"\n\n");                               //añadido
               System.out.printf("\n-----------------------------------------------------\n");                               
               pw.close();
               br2.close();                                                                          //añadido                                                                         
               cl.close();
           }
       }catch(Exception e){
           e.printStackTrace();
       }
   }  
}
