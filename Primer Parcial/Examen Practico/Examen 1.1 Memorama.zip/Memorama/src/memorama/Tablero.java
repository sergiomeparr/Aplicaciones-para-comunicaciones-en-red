package memorama;

import java.io.Serializable;
import java.util.Random;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Tablero implements Serializable {

    private Carta[][] carta;
    private int ancho;
    private int largo;

    public Tablero() {
        this.ancho = 5;
        this.largo = 4;
    }

    public Carta[][] getCarta() {
        return carta;
    }

    public void setCarta(Carta[][] carta) {
        this.carta = carta;
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public int getLargo() {
        return largo;
    }

    public void setLargo(int largo) {
        this.largo = largo;
    }

    public Carta[][] generarMemo() {
        Carta[][] c = new Carta[this.getAncho()][this.getLargo()];

        for (int f = 0; f < this.getAncho(); f++) {
            for (int c1 = 0; c1 < this.getLargo(); c1++) {
                c[f][c1] = new Carta();
                c[f][c1].setEstado(0);
                c[f][c1].setImagen(0);
            }
        }
        Random r = new Random();
        int i, j, k, l;
        int[] imagenes = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

         for (k=0; k < 10; k++) {
            for (l = 0; l < 2; l++) {
                do {
                    i = r.nextInt(5);
                    j = r.nextInt(4);
                } while (c[i][j].getImagen() !=0);
                c[i][j].setImagen(imagenes[k]);
            }
        }
        setCarta(c);
        return c;
    }

    @Override
    public String toString() {
        return "Tablero{" + "carta=" + carta + ", ancho=" + ancho + ", largo=" + largo + '}';
    }

    public static void main(String[] args) {
        Tablero t = new Tablero();
        Carta[][] c = t.generarMemo();

        for (int i = 0; i < t.ancho; i++) {
            for (int j = 0; j < t.largo; j++) {
                System.out.println(c[i][j].toString());
            }

        }

    }

}
