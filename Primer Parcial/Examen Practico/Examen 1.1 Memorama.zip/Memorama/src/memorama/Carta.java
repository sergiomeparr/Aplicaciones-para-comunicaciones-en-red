package memorama;

import java.io.Serializable;

public class Carta implements Serializable  {
    
    private int estado; //0 tapado 1 destapado
    private int imagen;

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    

    public void tapar() {
        this.estado = 0;
    }
    
    public void destapar() {
        this.estado = 1;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "Carta{" + "estado=" + estado + ", imagen=" + imagen + '}';
    }
    
    
    
}
