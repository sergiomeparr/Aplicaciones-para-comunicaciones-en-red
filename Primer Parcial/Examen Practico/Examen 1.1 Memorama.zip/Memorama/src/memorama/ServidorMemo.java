package memorama;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorMemo {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ServerSocket ss = new ServerSocket(9000);
        System.out.println("Servidor iniciado");
        for (;;) {
            Socket cl = ss.accept();
            ObjectOutputStream oos = new ObjectOutputStream(cl.getOutputStream());
            Tablero ob2 = new Tablero();
            ob2.generarMemo();
            oos.writeObject(ob2);
        }
    }
}
