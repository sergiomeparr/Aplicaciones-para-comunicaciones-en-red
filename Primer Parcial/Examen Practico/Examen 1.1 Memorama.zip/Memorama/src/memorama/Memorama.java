package memorama;

public class Memorama {

    
    public static void main(String[] args) {

    }
    
}
